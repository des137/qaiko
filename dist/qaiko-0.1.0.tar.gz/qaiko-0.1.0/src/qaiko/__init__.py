"""A simple example package."""

__version__ = "0.1.0"

from .main import greet

__all__ = ["greet"]
