# My qaiko

An example package to demonstrate PyPI uploads.

## Installation
```bash
pip install qaiko
```

## Usage
```python
from my_awesome_package import greet

print(greet("Python"))
```

Or from the command line:
```bash
qaiko
```
