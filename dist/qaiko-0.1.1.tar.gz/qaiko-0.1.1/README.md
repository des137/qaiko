# Qaiko

An example package to demonstrate PyPI uploads.

## Installation
```bash
pip install qaiko
```

## Usage
```python
from qaiko import greet

print(greet("Python"))
```

Or from the command line:
```bash
qaiko
```
